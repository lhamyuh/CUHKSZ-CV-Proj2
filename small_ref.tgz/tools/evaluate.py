"""Evaluate RGB renders in a split directory against its reference JPEGs."""
import argparse
import json
from pathlib import Path

import lpips
import numpy as np
import torch
from PIL import Image
from scipy.ndimage import gaussian_filter

def psnr(prediction, reference):
    mse = np.mean(np.square(prediction.astype(np.float64) - reference))
    return float(-10 * np.log10(max(mse, 1e-10)))

def ssim(prediction, reference):
    def smooth(image):
        return gaussian_filter(image, sigma=(1.5, 1.5, 0), radius=(5, 5, 0))
    x, y = prediction.astype(np.float64), reference.astype(np.float64)
    mx, my = smooth(x), smooth(y)
    luminance = (2*mx*my + 0.01**2) / (mx**2 + my**2 + 0.01**2)
    covariance = smooth(x*y) - mx*my
    variance = (smooth(x*x) - mx**2) + (smooth(y*y) - my**2)
    contrast = (2*covariance + 0.03**2) / (variance + 0.03**2)
    return float((luminance*contrast)[5:-5,5:-5].mean())


def evaluate(split, renders):
    cameras = json.loads((split / 'cameras.json').read_text())
    torch.set_num_threads(4)
    model = lpips.LPIPS(net='alex', version='0.1', verbose=False).eval()
    results = []
    for view in cameras['views']:
        name = view['name']
        arrays = []
        for path in [renders / Path(name).with_suffix('.png'), split / 'reference' / name]:
            with Image.open(path) as im:
                if im.size != (cameras['width'], cameras['height']) or im.mode != 'RGB':
                    raise ValueError(f'Expected native RGB at {path}')
                if not arrays and im.format != 'PNG':
                    raise ValueError(f'Expected PNG at {path}')
                arrays.append(np.asarray(im, dtype=np.float32) / 255)
        pred, ref = arrays
        tensors = [torch.from_numpy(a).permute(2,0,1)[None] * 2 - 1 for a in arrays]
        with torch.inference_mode():
            distance = model(*tensors).item()
        results.append(dict(name=name, psnr=psnr(pred,ref), ssim=ssim(pred,ref), lpips=distance))
    means = {k:float(np.mean([row[k] for row in results])) for k in ('psnr','ssim','lpips')}
    return dict(means=means, views=results)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for key in ('split','renders','output'):
        parser.add_argument(key,type=Path)
    args = parser.parse_args()
    result = evaluate(args.split,args.renders)
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False))
    print(result['means'])
