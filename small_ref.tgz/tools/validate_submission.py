"""Check the submission layout without importing or executing student code."""
import json
import sys
from pathlib import Path
from PIL import Image

def validate(root, cameras):
    errors=[]
    required = ('report.pdf','README.md','object_split.json',
                'scene/orbit.mp4','evidence/orbit.gif','evidence/loss.csv','evidence/loss.png',
                'evidence/stages.png','evidence/ablation.png','fusion/orbit.mp4',
                'fusion/placement.json')
    for name in required:
        path=root/name
        if not path.is_file() or not path.stat().st_size:
            errors.append(name)
    if not (root/'code').is_dir() or not any(p.is_file() for p in (root/'code').rglob('*')):
        errors.append('code/')
    for name in ('object_split.json','fusion/placement.json'):
        try:
            data=json.loads((root/name).read_text())
            if name.startswith('object'):
                sets=[set(data[k]) for k in ('train','val','test')]
                if not all(sets) or sum(map(len,sets))!=len(set.union(*sets)):
                    raise ValueError('empty or overlapping splits')
            else:
                matrix=data['object_to_scene']
                if len(matrix)!=4 or any(len(row)!=4 for row in matrix):
                    raise ValueError('expected 4 x 4')
        except (ValueError,KeyError,TypeError,OSError) as e:
            errors.append(f'{name}: {e}')
    for v in cameras['views']:
        path=root/'renders'/Path(v['name']).with_suffix('.png')
        try:
            with Image.open(path) as im:
                assert im.format=='PNG' and im.mode=='RGB' and im.size==(cameras['width'],cameras['height'])
                im.verify()
        except (AssertionError,OSError,SyntaxError) as e:
            errors.append(f'{path}: invalid or missing PNG {e}')
    if errors:
        raise SystemExit('\n'.join(errors))
    print('Required files and test PNGs present. Render and evidence quality require review.')

if __name__=='__main__':
    validate(Path(sys.argv[1]),json.loads(Path(sys.argv[2]).read_text()))
