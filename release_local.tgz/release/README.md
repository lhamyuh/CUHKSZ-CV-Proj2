# Assignment 2 release

This release fixes the task inputs to one Garden scene and two supplied object choices. Students reconstruct the Garden from `train/` and choose exactly one of the supplied objects:

- `object/camera/`: camera clips 1975, 1976 and 1977. Develop on 1975–1976 and reserve 1977 for testing.
- `object/white-plush/`: white plush clips 1978, 1979 and 1980. Develop on 1978–1979 and reserve 1980 for testing.

Students do not film a separate object and do not submit extra object source videos. `example/garden-plush.mp4` is a demonstration of tabletop contact and vase occlusion using a pink plush toy. It is not a third object choice, a required target, or a grading reference.

Place the selected object at a suitable location in Garden. The fusion video must establish the placement and demonstrate partial occlusion by an existing scene object, followed by the inserted object becoming visible again. The example's table and vase are optional choices.

The complete task, submission layout, camera conventions and grading rules are in `Project2_Guide_en.md` and `Project2_Guide_en.pdf`. The supplied `val/` split is for public tuning and metric self-checks; `test/` contains the cameras used for formal submission renders. `tools/evaluate.py` reports average and per-view metrics, without grade conversion. Matching the baseline on all three metrics earns 12 of the 20 metric points; the TA applies the weighted scoring rule to the formal test results. `tools/validate_submission.py` checks submission files and formats.

## Directory layout

| Directory | Purpose |
| --- | --- |
| `train/` | 161 Garden training images, cameras and the supplied COLMAP reconstruction. |
| `val/` | Public validation cameras, reference photographs and baseline renders for tuning and metric self-checks. |
| `test/` | Held-out test cameras for the formal submission renders; reference photographs remain with the TA. |
| `trajectory/` | The ordered Garden camera poses for the prescribed scene-only video. |
| `object/camera/` | Supplied camera clips: develop on 1975–1976 and reserve 1977 for testing. |
| `object/white-plush/` | Supplied white-plush clips: develop on 1978–1979 and reserve 1980 for testing. |
| `example/` | Demonstration video only; the pink plush is not an eligible object choice or grading target. |
| `figures/` | Figures used in the assignment guide. |
| `tools/` | Evaluation and submission-validation scripts. |
| `cvpr_latex_template/` | Supplied LaTeX template for the report. |
