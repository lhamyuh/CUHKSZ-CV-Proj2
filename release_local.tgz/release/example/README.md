# Demonstration only

`garden-plush.mp4` is a visual example of tabletop contact and vase occlusion using a pink plush toy. The pink toy is not one of the two eligible Task B objects, is not a required reconstruction target, and is not a grading reference. Students must choose either the supplied camera clips or the supplied white-plush clips described in `../object/README.md`.

The table and vase are example choices. Students may select another suitable location in Garden and another existing scene object for the occlusion-and-reveal sequence.
